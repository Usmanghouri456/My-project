def game_code():
    import keyboard
    global lives
    lives=4
    #from tkinter import *
    from tkinter import messagebox
    from playsound import playsound
    import random
    import pygame
    #from PIL import ImageTk, Image
    window = tk.Toplevel(root)
    window.title("Ready to Hang!! If you didn't find the word less than 5 chances")
    window.geometry("760x500")
    window.minsize(760,390)
    window.configure(bg='white')
    
    pygame.mixer.init()
    pygame.mixer.music.load("Whatsappaudio.mp3")
    pygame.mixer.music.play(loops=20)
    def r4():
        pygame.mixer.music.stop()

    def r2():
        root.deiconify()
    def r3():
        window.withdraw()
    def ublock_key():
        keyboard.unhook_all()

    image_paths=['Hang8.jpg','Hang5.jpeg','Hang1.jpeg','Hang2.jpeg','Hang6.jpeg']
    img = Image.open(image_paths[lives])
    img = img.resize((200,200), Image.ANTIALIAS)
    img = ImageTk.PhotoImage(img)
    panel = Label(window, image=img)
    panel.pack()
    panel.grid(column=0, row=0)

    restart=Button(window,text="RESTART",bg="red",fg="black",font="TimesNewRoman 8 bold",relief=GROOVE,command=lambda:[r2(),r3(), r4(),ublock_key()])
    restart.grid(column=0,row=4)
    f = open("alpha.txt", "r")
    data = f.read()
    a = data.split()
    word = random.choice(a)
    print(word)
    p=[]
    d=[]
    def block_key(x):
        global key
        key = x.keysym  # The key you want to block
        keyboard.block_key(key)

    def event(ab):
        global lives, z
        z = ab


        if ab.keysym in word:
            for i in range(len(word)):
                if lives>=0:
                    if ab.keysym == word[i]:
                        d[i].configure(text=ab.keysym)
                        p.append(ab.keysym)

                        block_key(ab)
                if lives<0 or len(word) == len(p) :
                    break



                print(p)

        else:
            if lives>=0:
                txt = "lives remaining " + str(lives)
                label1.configure(text=txt)
                image = Image.open(image_paths[lives])
                image = image.resize((200,200), Image.ANTIALIAS)
                imgnew = ImageTk.PhotoImage(image)
                panel.configure(image=imgnew)
                panel.image = imgnew
                lives = lives - 1

            if lives < 0:
                messagebox.showinfo("you lost", f"Hanged!!!!! \nThe correct word is {word}")

                txt1 = "no lives remaining"
                label1.configure(text=txt1)


        if len(word) == len(p):
            messagebox.showinfo(f"Congratulations!", "you have won")


        print(lives)


    window.bind_all('<Key>', event)
    for i in range(len(word)):

        y="x"+str(i)
        d.append(y)
        d[i]=Button(window,text=" ",width=5,height=2,bg="black",fg="white",font="Verdana 10 bold")
        if i==0:
            d[i].grid(row=0,column=3)
        else:
            d[i].grid(row=0,column=i+3)


    labl1 = Label(window, text="A", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))
    labl1.grid(column=2, row=2,pady= (25,0))
    labl2 = Label(window, text="B", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl2.grid(column=3, row=2,pady= (25,0))
    labl3 = Label(window, text="C", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl3.grid(column=4, row=2,pady= (25,0))
    labl4 = Label(window, text="D", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl4.grid(column=5, row=2,pady= (25,0))
    labl5 = Label(window, text="E", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl5.grid(column=6, row=2,pady= (25,0))
    labl6 = Label(window, text="F", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl6.grid(column=7, row=2,pady= (25,0))
    labl7 =Label (window, text="G", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl7.grid(column=8, row=2,pady= (25,0))
    labl8 = Label(window, text="H", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl8.grid(column=9, row=2,pady= (25,0))
    labl9 = Label(window, text="I", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl9.grid(column=2, row=3)
    labl10 = Label(window, text="J", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))
    labl10.grid(column=3, row=3)
    labl11 = Label(window, text="K", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl11.grid(column=4, row=3)
    labl12 = Label(window, text="L", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl12.grid(column=5, row=3)
    labl13 = Label(window, text="M", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl13.grid(column=6, row=3)
    labl14 = Label(window, text="N", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl14.grid(column=7, row=3)
    labl15 = Label(window, text="O", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl15.grid(column=8, row=3)
    labl16 = Label(window, text="P", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl16.grid(column=9, row=3)

    labl17 =Label(window, text="Q", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl17.grid(column=2, row=4)
    labl18 = Label(window, text="R", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl18.grid(column=3, row=4)
    labl19 = Label(window, text="S", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl19.grid(column=4, row=4)
    labl20 =Label (window, text="T", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl20.grid(column=5, row=4)
    labl21 = Label(window, text="U", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl21.grid(column=6, row=4)
    labl22 = Label(window, text="V", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl22.grid(column=7, row=4)
    labl23 = Label(window, text="W", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl23.grid(column=8, row=4)
    labl24 =Label(window, text="X", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))
    labl24.grid(column=9, row=4)

    labl25 = Label(window, text="Y", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl25.grid(column=5, row=5)
    labl25 = Label(window, text="Z", bg="Black", fg="white", width=3, height=1, font=('Helvetica', '20', 'bold'))

    labl25.grid(column=6, row=5)

    #label1 = Label(window, text="Total lives are : " + str(lives))
    label1 = Label(window, text="Total lives are : 5",bg="grey")
    label1.grid(row=5, column=0)

    window.mainloop()
import tkinter as tk
from tkinter import *

import pygame
from PIL import Image, ImageTk
from pygame import mixer
from playsound import playsound
pygame.mixer.init()
pygame.mixer.music.load("music 2.mpeg")
pygame.mixer.music.play(loops=0)
def stop():
    pygame.mixer.music.stop()



#chances=5
root= tk.Tk()
root.geometry("745x469")
def t2():
    root.withdraw()

image=Image.open('oppo.jpeg')
image = image.resize((745,469), Image.ANTIALIAS)

bg =ImageTk.PhotoImage(image)
# Create Canvas
canvas1 = Canvas(root, width=884,
                 height=469)
canvas1.pack(fill="both", expand=True)

# Display image
canvas1.create_image(5, 5, image=bg,anchor="nw")

button1=Button(root,text=" START THE GAME",font="Verdana 10  bold",bg="orange red",fg="black", relief=GROOVE,height=2,command=lambda: [stop(),t2(), game_code()])
button1_canvas = canvas1.create_window(500, 100,
                                       anchor="nw",
                                       window=button1)


def info():
    inf = tk.Toplevel()
    inf.title("instructions")
    inf.geometry("745x469")
    inf.minsize(749,469)
    inf.configure(bg="aquamarine4")
    my_text = Label(inf, text="INSTRUCTIONS", font="Helvetica 25 italic", fg="black", bg="aquamarine4",
                    relief="sunken")
    my_text.pack(pady=35, side=TOP, fill=Y)

    my_text1 = Label(inf, text="Guess the word before your man gets hung!", font="Verdana 20 italic", fg="black",
                     bg="aquamarine4",
                     relief="sunken")
    my_text1.pack(pady=35, side=TOP, fill=Y)



    my_text3 = Label(inf, text="Test your knowledge of english words containing any amount of letters."
                     , font="Verdana 19 italic", fg="black", bg='aquamarine4')
    my_text3.config(wraplength=700)
    my_text3.pack()

    my_text4 = Label(inf, text="These words belong to common use english language."
                     , font="Verdana 19 italic", fg="black", bg='aquamarine4')
    my_text4.config(wraplength=700)
    my_text4.pack()

    my_text5= Label(inf, text="Type  the letter you want to input using keyboard."
                     , font="Verdana 19 italic", fg="black", bg="aquamarine4")
    my_text5.config(wraplength=1000)
    my_text5.pack()

    my_text6 = Label(inf, text="Begin playing and be afraid."
                     , font="Verdana 19 italic", fg="black", bg='aquamarine4')
    my_text6.config(wraplength=1000)
    my_text6.pack()

    my_text7 = Label(inf, text="You have only 5 lives before you are hanged."
                     , font="Verdana 19 italic", fg="black", bg='aquamarine4')
    my_text7.config(wraplength=1000)
    my_text7.pack()

    inf.mainloop()


instructions = Button(root, text="INSTRUCTIONS", bg="orange red", fg="black", font="TimesNewRoman 10 bold", relief=GROOVE,height=1,
                      command=info)
instructions_canvas1 = canvas1.create_window(516,150,
                                       anchor="nw",
                                       window=instructions)

#button1.config(command=game_code)

root.title("HANGMAN GAME")
root.mainloop()